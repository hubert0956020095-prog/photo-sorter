# 相簿整理 AI 📸

一個**獨立**的手機網頁小工具（**跟 MINGO 無關、零後端**）：
你告訴它要挑什麼（刺青、貓、菜單、收據…），選一批照片，AI 就把**符合的挑出來**，讓你**打包下載**。

## 特色
- **純前端單頁**：只有 `index.html` + 圖示 + manifest，沒有伺服器、沒有資料庫。
- **照片不外流**：照片直接從你手機傳給 Google Gemini 判斷，**不經過任何中間伺服器**；金鑰只存在你手機瀏覽器（localStorage）。
- **可加到主畫面當 App 用**（PWA）。
- 挑出來的照片可**打包成 ZIP 下載**（存到 iPhone 的「檔案」）。

## 怎麼用
1. 申請一組免費的 **Google Gemini API 金鑰**：<https://aistudio.google.com/apikey>
2. 打開 `index.html`（見下方「部署」），第一次貼上金鑰。
3. 在「你要我幫你挑出什麼？」輸入要的東西（或點下方範例）。
4. 按「選照片，開始整理」，從手機相簿選一批照片。
5. AI 一張張判斷，把符合的挑出來 → 按「打包下載」拿到 ZIP。

## 部署（三選一）
- **最簡單／手機加到主畫面**：把整個 `photo-sorter` 資料夾丟到任何靜態網站空間
  （GitHub Pages、Netlify、Vercel 都行），用手機瀏覽器打開那個網址，Safari「分享 → 加入主畫面」就變 App。
- **GitHub Pages**：把這個資料夾的內容推到一個 repo、開 Pages，指向該資料夾即可。
- **本機試用**：在這個資料夾跑 `python -m http.server 8000`，瀏覽器開 `http://localhost:8000`。
  （直接用 `file://` 開也可以，但 PWA／部分功能在 http 下才完整。）

## 換辨識模型
預設用 `gemini-2.5-flash`。要換的話，改 `index.html` 最上方 `const MODEL = '...'`。

## 隱私
- 金鑰與「上次要挑的東西」只存在你手機瀏覽器，清除瀏覽器資料就沒了。
- 照片內容只送往 Google Gemini API（你自己的金鑰）做判斷，本工具不保存、不上傳到別處。
- 建議到 Google AI Studio 對金鑰設用量上限／限制，較安全。
